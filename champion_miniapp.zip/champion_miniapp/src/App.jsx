import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';
import { useFoundation } from '@picsart/design-system/foundation/initFoundation';
import { ThemeLightValues, ThemeDarkValues } from '@picsart/design-system/foundation/themes';
import { usePicsart } from './PicsartProvider';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Apply from './pages/Apply';
import Pending from './pages/Pending';
import Dashboard from './pages/Dashboard';
import Posts from './pages/Posts';
import Leaderboard from './pages/Leaderboard';
import Earnings from './pages/Earnings';
import Accounts from './pages/Accounts';
import CampaignDetail from './pages/CampaignDetail';
import Layout from './components/Layout';
import './App.css';

export default function App() {
  const [userState, setUserState] = useState('landing');
  const { theme } = usePicsart();

  // DS adds .dark / .light class to <html> and injects CSS variables
  useFoundation({
    themes: [
      { key: 'dark', value: ThemeDarkValues, selected: theme === 'dark' },
      { key: 'light', value: ThemeLightValues, selected: theme === 'light' },
    ],
    writingMode: 'ltr',
  });

  return (
    <BrowserRouter>
      <Routes>
        {userState === 'landing' && (
          <>
            <Route
              path="/"
              element={<Landing onGetStarted={() => setUserState('login')} />}
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </>
        )}
        {userState === 'login' && (
          <>
            <Route
              path="/login"
              element={<Login onLogin={() => setUserState('approved')} />}
            />
            <Route path="*" element={<Navigate to="/login" replace />} />
          </>
        )}
        {userState === 'visitor' && (
          <>
            <Route path="/apply" element={<Apply onSubmit={() => setUserState('pending')} />} />
            <Route path="*" element={<Navigate to="/apply" replace />} />
          </>
        )}
        {userState === 'pending' && (
          <>
            <Route
              path="/pending"
              element={<Pending onApprove={() => setUserState('approved')} />}
            />
            <Route path="*" element={<Navigate to="/pending" replace />} />
          </>
        )}
        {userState === 'approved' && (
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/campaign/:id" element={<CampaignDetail />} />
            <Route path="/posts" element={<Posts />} />
            <Route path="/accounts" element={<Accounts />} />
            <Route path="/earnings" element={<Earnings />} />
            <Route path="/billing" element={<Earnings />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Route>
        )}
      </Routes>
    </BrowserRouter>
  );
}
