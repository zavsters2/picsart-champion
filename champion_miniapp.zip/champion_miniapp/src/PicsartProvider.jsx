import { createContext as createReactContext, useContext, useEffect, useState } from 'react';
import { getPicsartContext, isInsidePicsart } from './picsart';

const PicsartCtx = createReactContext({
  theme: 'dark',
  user: null,
  isInPicsart: false,
  close: () => {},
});

export function PicsartProvider({ children }) {
  const [theme, setTheme] = useState('dark');
  const [user, setUser] = useState(null);
  const ctx = getPicsartContext();
  const inPicsart = isInsidePicsart();

  useEffect(() => {
    if (!ctx) return;

    // Subscribe to theme changes
    const unsubTheme = ctx.general.theme.subscribe((t) => {
      setTheme(t || 'dark');
    });

    // Subscribe to auth/user info
    const unsubAuth = ctx.general.auth.subscribe((authInfo) => {
      setUser(authInfo || null);
    });

    return () => {
      unsubTheme?.();
      unsubAuth?.();
    };
  }, [ctx]);

  const close = () => {
    ctx?.handlers.close();
  };

  return (
    <PicsartCtx.Provider value={{ theme, user, isInPicsart: inPicsart, close }}>
      {children}
    </PicsartCtx.Provider>
  );
}

export function usePicsart() {
  return useContext(PicsartCtx);
}
