import './Header.css';

export default function Header({ onLogin, minimal }) {
  return (
    <header className="pa-header">
      <div className="pa-header-inner">
        {/* Logo */}
        <a href="#" className="pa-header-logo" onClick={(e) => e.preventDefault()}>
          <span className="pa-logo-text">Picsart</span>
        </a>

        {!minimal && (
          <>
            {/* Nav links */}
            <nav className="pa-header-nav">
              <button className="pa-header-link">
                Create
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button className="pa-header-link">
                Solutions
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button className="pa-header-link">
                Learn & connect
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button className="pa-header-link">Pricing</button>
            </nav>

            {/* Right actions */}
            <div className="pa-header-actions">
              <button className="pa-header-search" aria-label="Search">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M13 13l3.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
              <button className="pa-header-cta">Start creating</button>
              <button className="pa-header-login" onClick={onLogin}>Log in</button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}
