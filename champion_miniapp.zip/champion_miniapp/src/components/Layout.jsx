import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { MOCK_CHAMPION } from '../data/mock';
import './Layout.css';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="1" y="1" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="10" y="1" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="1" y="10" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="10" y="10" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/></svg>
  )},
  { to: '/posts', label: 'Submitted posts', icon: (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="2" y="2" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M6 7h6M6 10h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
  )},
];

const ACCOUNT_ITEMS = [
  { to: '/accounts', label: 'My accounts', icon: (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="1.5" y="4" width="15" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M1.5 8h15" stroke="currentColor" strokeWidth="1.5"/></svg>
  )},
  { to: '/billing', label: 'Billing history', icon: (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="3" y="2" width="12" height="14" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M6 6h6M6 9h6M6 12h3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
  )},
];

export default function Layout() {
  const c = MOCK_CHAMPION;
  const navigate = useNavigate();

  return (
    <div className="layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-top">
          {/* Brand */}
          <div className="sidebar-brand">
            <div className="sidebar-logo">
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <defs>
                  <linearGradient id="pLogo" x1="0" y1="0" x2="28" y2="28">
                    <stop offset="0%" stopColor="#C12CD1"/>
                    <stop offset="100%" stopColor="#8B2FA8"/>
                  </linearGradient>
                </defs>
                <rect width="28" height="28" rx="7" fill="url(#pLogo)"/>
                <path d="M10 20V8h4.5a4.5 4.5 0 010 9H10" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="sidebar-brand-text">
              <span className="sidebar-brand-name">Picsart</span>
              <span className="sidebar-brand-sub">Champion</span>
            </div>
          </div>

          {/* Main nav */}
          <nav className="sidebar-nav">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `sidebar-link ${isActive ? 'sidebar-link--active' : ''}`}
              >
                <span className="sidebar-link-icon">{item.icon}</span>
                <span className="sidebar-link-label">{item.label}</span>
              </NavLink>
            ))}
          </nav>

          {/* Account settings section */}
          <div className="sidebar-section-label">Account Settings</div>
          <nav className="sidebar-nav">
            {ACCOUNT_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `sidebar-link ${isActive ? 'sidebar-link--active' : ''}`}
              >
                <span className="sidebar-link-icon">{item.icon}</span>
                <span className="sidebar-link-label">{item.label}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Balance card */}
        <div className="sidebar-bottom">
          <div className="sidebar-balance" onClick={() => navigate('/earnings')} role="button" tabIndex={0}>
            <span className="sidebar-balance-label">Your Balance</span>
            <span className="sidebar-balance-amount">$ {c.totalEarnings.toFixed(2)}</span>
          </div>

          {/* User info */}
          <div className="sidebar-user">
            <img src={c.avatar} alt="" className="sidebar-user-avatar" />
            <div className="sidebar-user-info">
              <span className="sidebar-user-name">{c.name}</span>
              <span className="sidebar-user-email">sarah@email.com</span>
            </div>
            <button className="sidebar-logout" onClick={() => window.location.reload()} title="Log out">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M6 2H4a2 2 0 00-2 2v8a2 2 0 002 2h2M10.5 11.5L14 8l-3.5-3.5M6 8h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="mobile-topbar">
        <div className="mobile-brand">
          <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
            <defs>
              <linearGradient id="pLogoM" x1="0" y1="0" x2="28" y2="28">
                <stop offset="0%" stopColor="#C12CD1"/>
                <stop offset="100%" stopColor="#8B2FA8"/>
              </linearGradient>
            </defs>
            <rect width="28" height="28" rx="7" fill="url(#pLogoM)"/>
            <path d="M10 20V8h4.5a4.5 4.5 0 010 9H10" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span>Champion</span>
        </div>
        <img src={c.avatar} alt="" className="mobile-avatar" />
      </header>

      {/* Main content */}
      <main className="layout-main">
        <Outlet />
      </main>

      {/* Mobile bottom nav */}
      <nav className="mobile-nav">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => `mobile-nav-item ${isActive ? 'mobile-nav-item--active' : ''}`}
          >
            <span className="mobile-nav-icon">{item.icon}</span>
            <span className="mobile-nav-label">{item.label}</span>
          </NavLink>
        ))}
        <NavLink
          to="/earnings"
          className={({ isActive }) => `mobile-nav-item ${isActive ? 'mobile-nav-item--active' : ''}`}
        >
          <span className="mobile-nav-icon">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7.5" stroke="currentColor" strokeWidth="1.5"/><path d="M9 5v8M6.5 7.5h5M7 12h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </span>
          <span className="mobile-nav-label">Earnings</span>
        </NavLink>
      </nav>
    </div>
  );
}
