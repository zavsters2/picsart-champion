import './ProgressBar.css';

export default function ProgressBar({ value, max, label, sublabel, color }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="progress-bar-container">
      {label && (
        <div className="progress-header">
          <span className="progress-label">{label}</span>
          {sublabel && <span className="progress-sublabel">{sublabel}</span>}
        </div>
      )}
      <div className="progress-track">
        <div
          className="progress-fill"
          style={{ width: `${pct}%`, backgroundColor: color || 'var(--accent)' }}
        />
      </div>
    </div>
  );
}
