import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { initPicsart } from './picsart'
import { PicsartProvider } from './PicsartProvider'
import '@picsart/design-system/foundation.css'
import App from './App.jsx'
import './index.css'

// Initialize Picsart miniapp SDK before rendering
initPicsart()

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <PicsartProvider>
      <App />
    </PicsartProvider>
  </StrictMode>,
)
