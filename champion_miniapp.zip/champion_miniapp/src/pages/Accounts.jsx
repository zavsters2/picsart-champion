import './Accounts.css';

const PLATFORMS = [
  {
    id: 'instagram',
    name: 'Instagram',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="2" width="20" height="20" rx="6" stroke="currentColor" strokeWidth="1.5"/>
        <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="1.5"/>
        <circle cx="18" cy="6" r="1.5" fill="currentColor"/>
      </svg>
    ),
    connected: true,
    handle: '@sarahcreates',
    followers: '12.4K',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M15 3v10a5 5 0 11-4-4.9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M15 6.5c1.5 1.2 3.3 1.5 4.5 1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    ),
    connected: true,
    handle: '@sarahcreates',
    followers: '8.2K',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="5" width="20" height="14" rx="4" stroke="currentColor" strokeWidth="1.5"/>
        <path d="M10 9v6l5-3-5-3z" fill="currentColor"/>
      </svg>
    ),
    connected: false,
    handle: null,
    followers: null,
  },
  {
    id: 'twitter',
    name: 'X (Twitter)',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M4 4l6.5 8L4 20h2l5.5-6.8L16 20h4l-6.8-8.5L19.5 4h-2l-5 6.2L8 4H4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
      </svg>
    ),
    connected: false,
    handle: null,
    followers: null,
  },
];

export default function Accounts() {
  return (
    <div className="accounts-page">
      <h1 className="accounts-title">My Accounts</h1>
      <p className="accounts-subtitle">Connect your social media accounts to participate in campaigns and track performance.</p>

      <div className="accounts-list">
        {PLATFORMS.map((p) => (
          <div className={`account-card ${p.connected ? 'account-card--connected' : ''}`} key={p.id}>
            <div className="account-card-left">
              <span className="account-card-icon">{p.icon}</span>
              <div className="account-card-info">
                <span className="account-card-name">{p.name}</span>
                {p.connected ? (
                  <span className="account-card-handle">{p.handle} · {p.followers} followers</span>
                ) : (
                  <span className="account-card-handle">Not connected</span>
                )}
              </div>
            </div>
            <button className={`account-card-btn ${p.connected ? 'account-card-btn--connected' : ''}`}>
              {p.connected ? 'Connected' : 'Connect'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
