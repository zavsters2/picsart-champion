import { useState } from 'react';
import { Button, ButtonVariants, ButtonSizeLG } from '@picsart/design-system/components/Button';
import { Progress, ProgressVariants } from '@picsart/design-system/components/Progress';
import { Text, TextElementTypes } from '@picsart/design-system/components/Text';

import WelcomeStep from './apply-steps/WelcomeStep';
import HowItWorksStep from './apply-steps/HowItWorksStep';
import BenefitsStep from './apply-steps/BenefitsStep';
import DetailsStep from './apply-steps/DetailsStep';
import SocialsStep from './apply-steps/SocialsStep';
import ReviewStep from './apply-steps/ReviewStep';
import './Apply.css';

const STEPS = [
  { id: 'welcome', component: WelcomeStep, label: 'Get Started' },
  { id: 'how-it-works', component: HowItWorksStep, label: 'Next' },
  { id: 'benefits', component: BenefitsStep, label: 'Next' },
  { id: 'details', component: DetailsStep, label: 'Next' },
  { id: 'socials', component: SocialsStep, label: 'Next' },
  { id: 'review', component: ReviewStep, label: 'Submit Application' },
];

function getValidationHint(step, formData) {
  switch (step) {
    case 3: {
      const missing = [];
      if (!formData.name.trim()) missing.push('name');
      if (!formData.email.trim()) missing.push('email');
      return missing.length > 0 ? `Enter your ${missing.join(' and ')} to continue` : '';
    }
    case 4:
      return formData.platforms.length === 0 ? 'Enter at least one handle to continue' : '';
    case 5: {
      const missing = [];
      if (!formData.name.trim()) missing.push('name');
      if (!formData.email.trim()) missing.push('email');
      if (formData.platforms.length === 0) missing.push('a platform');
      return missing.length > 0 ? `Missing: ${missing.join(', ')}` : '';
    }
    default:
      return '';
  }
}

function validateStep(step, formData) {
  switch (step) {
    case 0:
    case 1:
    case 2:
      return true;
    case 3:
      return formData.name.trim() !== '' && formData.email.trim() !== '';
    case 4:
      return formData.platforms.length > 0;
    case 5:
      return (
        formData.name.trim() !== '' &&
        formData.email.trim() !== '' &&
        formData.platforms.length > 0
      );
    default:
      return false;
  }
}

export default function Apply({ onSubmit }) {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState('forward');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    platforms: [],
    handles: {},
    whyJoin: '',
  });

  const progressPercent = ((step + 1) / STEPS.length) * 100;
  const canProceed = validateStep(step, formData);
  const hint = getValidationHint(step, formData);
  const isLast = step === STEPS.length - 1;

  const goNext = () => {
    if (!canProceed) return;
    if (isLast) {
      onSubmit(formData);
      return;
    }
    setDirection('forward');
    setStep((s) => s + 1);
  };

  const goBack = () => {
    setDirection('backward');
    setStep((s) => Math.max(s - 1, 0));
  };

  const goToStep = (n) => {
    setDirection(n < step ? 'backward' : 'forward');
    setStep(n);
  };

  const StepComponent = STEPS[step].component;

  return (
    <div className="wizard-page">
      {step > 0 && (
        <div className="wizard-progress">
          <Progress
            variant={ProgressVariants.Linear}
            percent={progressPercent}
            isFullWidth
          />
          <Text elementType={TextElementTypes.Span} className="wizard-step-label">
            Step {step} of {STEPS.length - 1}
          </Text>
        </div>
      )}

      <div className={`wizard-content wizard-slide-${direction}`} key={step}>
        <StepComponent
          formData={formData}
          setFormData={setFormData}
          goToStep={goToStep}
        />
      </div>

      <div className="wizard-nav">
        {hint && (
          <Text elementType={TextElementTypes.Span} className="wizard-hint">
            {hint}
          </Text>
        )}
        <div className="wizard-nav-buttons">
          {step > 0 && (
            <Button
              variant={ButtonVariants.Outline}
              size={ButtonSizeLG}
              onClick={goBack}
            >
              Back
            </Button>
          )}
          <Button
            variant={ButtonVariants.Filled}
            size={ButtonSizeLG}
            isFullWidth
            isDisabled={!canProceed}
            onClick={goNext}
          >
            {STEPS[step].label}
          </Button>
        </div>
      </div>
    </div>
  );
}
