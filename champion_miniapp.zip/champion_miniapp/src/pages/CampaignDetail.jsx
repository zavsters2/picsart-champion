import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_CAMPAIGNS, CONNECTED_PLATFORMS } from '../data/mock';
import './CampaignDetail.css';

const PLATFORM_ICONS = {
  Instagram: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="2" y="2" width="16" height="16" rx="5" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="10" cy="10" r="4" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="15" cy="5" r="1.2" fill="currentColor"/>
    </svg>
  ),
  YouTube: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="2" y="4" width="16" height="12" rx="3" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M8 7.5v5l4.5-2.5L8 7.5z" fill="currentColor"/>
    </svg>
  ),
  TikTok: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M12 3v8.5a3.5 3.5 0 11-3-3.46" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <path d="M12 5.5c1.2 1 2.8 1.2 3.5 1.2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
};

const STEPS = [
  { num: '1', title: 'Create your content', desc: 'Use Picsart AI tools to create content following the campaign guidelines.' },
  { num: '2', title: 'Post on social media', desc: 'Share your creation on the required platform with the campaign hashtags.' },
  { num: '3', title: 'Submit your link', desc: 'Paste the link to your post below so we can track your performance.' },
];

export default function CampaignDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const campaign = MOCK_CAMPAIGNS.find((c) => c.id === Number(id));
  const [step, setStep] = useState('info'); // 'info' | 'submit' | 'done'
  const [postLink, setPostLink] = useState('');

  if (!campaign) {
    return (
      <div className="cd-page">
        <p style={{ color: 'rgba(255,255,255,0.5)' }}>Campaign not found.</p>
        <button className="cd-back" onClick={() => navigate('/dashboard')}>Back to Dashboard</button>
      </div>
    );
  }

  const isLocked = !CONNECTED_PLATFORMS.includes(campaign.platform);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!postLink.trim()) return;
    setStep('done');
  };

  return (
    <div className="cd-page">
      {/* Back button */}
      <button className="cd-back" onClick={() => navigate('/dashboard')}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M10 3L5 8l5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        All Campaigns
      </button>

      {/* Hero image */}
      <div className="cd-hero">
        <img src={campaign.image} alt="" className="cd-hero-img" />
        <div className="cd-hero-fade" />
        <div className="cd-hero-badge">
          {PLATFORM_ICONS[campaign.platform]}
          {campaign.platform}
        </div>
      </div>

      {/* Campaign info */}
      <div className="cd-info">
        <h1 className="cd-title">{campaign.title}</h1>
        <p className="cd-desc">{campaign.description}</p>

        <div className="cd-meta-row">
          <div className="cd-meta-item">
            <span className="cd-meta-label">Reward</span>
            <span className="cd-meta-value cd-meta-value--reward">{campaign.reward}</span>
          </div>
          <div className="cd-meta-item">
            <span className="cd-meta-label">Deadline</span>
            <span className="cd-meta-value">{new Date(campaign.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
          <div className="cd-meta-item">
            <span className="cd-meta-label">Participants</span>
            <span className="cd-meta-value">{campaign.participants} creators</span>
          </div>
        </div>
      </div>

      {/* Locked state */}
      {isLocked && (
        <div className="cd-locked-banner">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/>
            <path d="M8 11V7a4 4 0 118 0v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          <div>
            <strong>Connect {campaign.platform} to participate</strong>
            <span>Go to My Accounts to link your {campaign.platform} account.</span>
          </div>
          <button className="cd-locked-btn" onClick={() => navigate('/accounts')}>Connect</button>
        </div>
      )}

      {/* How it works */}
      {!isLocked && step === 'info' && (
        <div className="cd-section">
          <h2 className="cd-section-title">How to participate</h2>
          <div className="cd-steps">
            {STEPS.map((s) => (
              <div className="cd-step" key={s.num}>
                <span className="cd-step-num">{s.num}</span>
                <div className="cd-step-text">
                  <strong>{s.title}</strong>
                  <span>{s.desc}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="cd-guidelines">
            <h3 className="cd-guidelines-title">Campaign guidelines</h3>
            <ul className="cd-guidelines-list">
              <li>Content must be original and created using Picsart AI tools</li>
              <li>Include <strong>#{campaign.platform === 'TikTok' ? 'PicsartAI' : 'Picsart'}</strong> in your caption</li>
              <li>Post must be public and remain live for at least 30 days</li>
              <li>One submission per creator per campaign</li>
              <li>Content will be reviewed within 48 hours of submission</li>
            </ul>
          </div>

          <button className="cd-participate-btn" onClick={() => setStep('submit')}>
            Participate Now
          </button>
        </div>
      )}

      {/* Submit post form */}
      {!isLocked && step === 'submit' && (
        <div className="cd-section">
          <h2 className="cd-section-title">Submit your post</h2>
          <p className="cd-section-sub">Paste the link to your {campaign.platform} post below. Make sure it's public.</p>

          <form className="cd-submit-form" onSubmit={handleSubmit}>
            <div className="cd-input-wrap">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className="cd-input-icon">
                <path d="M7.5 10.5l3-3m-1.5-1.5L11.25 3.75a2.121 2.121 0 013 3L12 9m-3 1.5L6.75 14.25a2.121 2.121 0 01-3-3L6 9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <input
                type="url"
                className="cd-input"
                placeholder={`https://${campaign.platform.toLowerCase()}.com/your-post-link`}
                value={postLink}
                onChange={(e) => setPostLink(e.target.value)}
                autoFocus
              />
            </div>

            <div className="cd-submit-actions">
              <button type="button" className="cd-cancel-btn" onClick={() => setStep('info')}>
                Back
              </button>
              <button type="submit" className="cd-submit-btn" disabled={!postLink.trim()}>
                Submit Post
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Success state */}
      {step === 'done' && (
        <div className="cd-section cd-success">
          <div className="cd-success-icon">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="2"/>
              <path d="M10 16.5l4 4 8-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h2 className="cd-success-title">Post submitted!</h2>
          <p className="cd-success-desc">
            Your post is being reviewed. You'll see it in your Submitted Posts once approved.
            This usually takes up to 48 hours.
          </p>
          <div className="cd-success-actions">
            <button className="cd-participate-btn" onClick={() => navigate('/posts')}>
              View My Posts
            </button>
            <button className="cd-cancel-btn" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
