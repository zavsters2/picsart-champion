import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_CAMPAIGNS, CONNECTED_PLATFORMS } from '../data/mock';
import './Dashboard.css';

const FILTERS = ['All', 'Instagram', 'YouTube', 'TikTok'];

const PLATFORM_ICONS = {
  Instagram: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="1" width="14" height="14" rx="4" stroke="currentColor" strokeWidth="1.3"/>
      <circle cx="8" cy="8" r="3.2" stroke="currentColor" strokeWidth="1.3"/>
      <circle cx="12" cy="4" r="1" fill="currentColor"/>
    </svg>
  ),
  YouTube: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="10" rx="3" stroke="currentColor" strokeWidth="1.3"/>
      <path d="M6.5 6v4l3.5-2-3.5-2z" fill="currentColor"/>
    </svg>
  ),
  TikTok: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M10 2v7a3 3 0 11-2.5-2.96" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
      <path d="M10 4.5c1 .8 2.2 1 3 1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
    </svg>
  ),
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState('All');

  const filtered = activeFilter === 'All'
    ? MOCK_CAMPAIGNS
    : MOCK_CAMPAIGNS.filter((c) => c.platform === activeFilter);

  return (
    <div className="dash">
      {/* Hero section */}
      <div className="dash-hero">
        <div className="dash-hero-collage">
          <img src="https://picsum.photos/seed/hero1/400/500" alt="" className="dash-hero-img dash-hero-img--1" />
          <img src="https://picsum.photos/seed/hero2/400/500" alt="" className="dash-hero-img dash-hero-img--2" />
          <img src="https://picsum.photos/seed/hero3/400/500" alt="" className="dash-hero-img dash-hero-img--3" />
          <img src="https://picsum.photos/seed/hero4/400/500" alt="" className="dash-hero-img dash-hero-img--4" />
          <div className="dash-hero-fade" />
        </div>
        <div className="dash-hero-content">
          <h1 className="dash-hero-title">PICSART<br/>CHAMPION</h1>
          <p className="dash-hero-sub">Get paid to create content with Picsart tools. Join campaigns, share your creativity, and earn real money.</p>
          <button className="dash-hero-btn" onClick={() => document.getElementById('campaigns')?.scrollIntoView({ behavior: 'smooth' })}>How it works</button>
        </div>
      </div>

      {/* Campaigns section */}
      <section className="dash-campaigns" id="campaigns">
        <div className="dash-campaigns-header">
          <h2 className="dash-campaigns-title">ALL CAMPAIGNS</h2>
          <div className="dash-filters">
            {FILTERS.map((f) => (
              <button
                key={f}
                className={`dash-filter ${activeFilter === f ? 'dash-filter--active' : ''}`}
                onClick={() => setActiveFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="dash-campaigns-grid">
          {filtered.map((campaign) => {
            const isLocked = !CONNECTED_PLATFORMS.includes(campaign.platform);
            return (
              <div className="campaign-card" key={campaign.id} onClick={() => navigate(`/campaign/${campaign.id}`)} style={{ cursor: 'pointer' }}>
                <div className="campaign-card-img-wrap">
                  <img src={campaign.image} alt="" className="campaign-card-img" />
                  <span className="campaign-card-platform">
                    {PLATFORM_ICONS[campaign.platform]}
                    {campaign.platform}
                  </span>
                  {isLocked && (
                    <div className="campaign-card-lock">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect x="5" y="11" width="14" height="10" rx="2" stroke="white" strokeWidth="1.5"/>
                        <path d="M8 11V7a4 4 0 118 0v4" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                      </svg>
                      <span>Connect {campaign.platform} to Participate</span>
                    </div>
                  )}
                </div>
                <div className="campaign-card-body">
                  <h3 className="campaign-card-name">{campaign.title}</h3>
                  <p className="campaign-card-desc">{campaign.description}</p>
                  <div className="campaign-card-meta">
                    <span className="campaign-card-reward">{campaign.reward}</span>
                    {!isLocked && (
                      <span className="campaign-card-participants">{campaign.participants} creators</span>
                    )}
                  </div>
                  {!isLocked && (
                    <span className="campaign-card-btn">Participate</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
