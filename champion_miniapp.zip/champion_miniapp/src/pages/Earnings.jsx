import { MOCK_CHAMPION, MOCK_POSTS, VIEW_MILESTONES } from '../data/mock';
import './Earnings.css';

export default function Earnings() {
  const c = MOCK_CHAMPION;

  const basePay = MOCK_POSTS.filter((p) => p.status === 'approved').length * c.level.baseRate;
  const viewBonuses = MOCK_POSTS.reduce((sum, p) => {
    return sum + VIEW_MILESTONES.filter((m) => p.views >= m.views).reduce((s, m) => s + m.bonus, 0);
  }, 0);
  const installEarnings = c.installs * 1.5;

  const breakdownItems = [
    { label: 'Base post payments', amount: basePay, detail: `${MOCK_POSTS.filter((p) => p.status === 'approved').length} posts x $${c.level.baseRate}` },
    { label: 'View milestone bonuses', amount: viewBonuses, detail: 'Across all posts' },
    { label: 'Install commissions', amount: installEarnings, detail: `${c.installs} installs x $1.50` },
  ];

  return (
    <div className="earnings-page">
      <h1 className="earnings-title">Earnings</h1>

      {/* Hero card */}
      <div className="earnings-hero">
        <span className="earnings-hero-label">TOTAL EARNED</span>
        <span className="earnings-hero-value">${c.totalEarnings.toFixed(2)}</span>
        <span className="earnings-hero-pending">${c.pendingPayout.toFixed(2)} pending payout</span>
      </div>

      {/* Breakdown */}
      <section className="earn-section">
        <h2 className="earn-section-title">Breakdown — This Month</h2>
        <div className="earn-table">
          {breakdownItems.map((item) => (
            <div className="earn-row" key={item.label}>
              <div className="earn-row-info">
                <span className="earn-row-label">{item.label}</span>
                <span className="earn-row-detail">{item.detail}</span>
              </div>
              <span className="earn-row-amount">${item.amount.toFixed(2)}</span>
            </div>
          ))}
          <div className="earn-row earn-row--total">
            <span className="earn-row-label">Total</span>
            <span className="earn-row-amount">${(basePay + viewBonuses + installEarnings).toFixed(2)}</span>
          </div>
        </div>
      </section>

      {/* Payout info */}
      <section className="earn-section">
        <h2 className="earn-section-title">Payout Info</h2>
        <div className="earn-table">
          <div className="earn-row">
            <span className="earn-row-dim">Payout schedule</span>
            <span className="earn-row-val">Monthly</span>
          </div>
          <div className="earn-row">
            <span className="earn-row-dim">Minimum payout</span>
            <span className="earn-row-val">$50.00</span>
          </div>
          <div className="earn-row">
            <span className="earn-row-dim">Payment method</span>
            <span className="earn-row-val">PayPal</span>
          </div>
          <div className="earn-row">
            <span className="earn-row-dim">Next payout</span>
            <span className="earn-row-val">Mar 1, 2026</span>
          </div>
        </div>
      </section>

      {/* Milestone bonuses */}
      <section className="earn-section">
        <h2 className="earn-section-title">View Milestone Bonuses</h2>
        <div className="earn-table">
          {VIEW_MILESTONES.map((m) => (
            <div className="earn-row" key={m.views}>
              <span className="earn-row-dim">{m.label} views</span>
              <span className="earn-row-amount">+${m.bonus}</span>
            </div>
          ))}
        </div>
        <p className="earn-note">Bonuses are per post. Each post earns every milestone it reaches.</p>
      </section>
    </div>
  );
}
