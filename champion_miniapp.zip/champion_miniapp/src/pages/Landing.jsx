import Header from '../components/Header';
import './Landing.css';

const STEPS = [
  {
    id: 'signup',
    num: '01',
    title: 'SIGN UP',
    desc: 'Connect your Social Media account and verify ownership instantly. No waiting for manual approval.',
  },
  {
    id: 'create',
    num: '02',
    title: 'CREATE & SHARE',
    desc: 'Create content with Picsart AI tools, post it to your feed. Paste the link into your dashboard to begin tracking.',
  },
  {
    id: 'earn',
    num: '03',
    title: 'GET PAID',
    desc: 'Unlock 3-tier rewards: payment for every approved post, plus view bonuses and referral commissions.',
  },
];

const CAMPAIGNS = [
  {
    platform: 'INSTAGRAM',
    title: 'AI Backgrounds',
    desc: 'Use Picsart AI Background to create stunning scenes and share the magic.',
    payout: '$2,500',
    endDate: '28.02.2026',
    img: 'https://picsum.photos/seed/camp-bg/520/300',
  },
  {
    platform: 'TIKTOK',
    title: 'AI Enhance Challenge',
    desc: 'Show before/after transformations using Picsart AI Enhance tool.',
    payout: '$3,000',
    endDate: '15.03.2026',
    img: 'https://picsum.photos/seed/camp-enhance/520/300',
  },
  {
    platform: 'YOUTUBE',
    title: 'Creative Workflow',
    desc: 'Create a tutorial showcasing your creative workflow with Picsart tools.',
    payout: '$1,800',
    endDate: '10.03.2026',
    img: 'https://picsum.photos/seed/camp-workflow/520/300',
  },
];

export default function Landing({ onGetStarted }) {
  return (
    <div className="landing">
      <Header onLogin={onGetStarted} />
      {/* ── Hero ── */}
      <section className="land-hero">
        <div className="land-hero-bg">
          <div className="land-hero-gradient" />
          <div className="land-hero-orb land-hero-orb--1" />
          <div className="land-hero-orb land-hero-orb--2" />
          <div className="land-hero-orb land-hero-orb--3" />
        </div>

        <div className="land-hero-inner">
        <div className="land-hero-content">
          <span className="land-badge land-anim" style={{ animationDelay: '0.1s' }}>
            OFFICIAL CREATOR PROGRAM
          </span>
          <h1 className="land-title land-anim" style={{ animationDelay: '0.2s' }}>
            PICSART
            <br />
            CHAMPION
          </h1>
          <p className="land-subtitle land-anim" style={{ animationDelay: '0.35s' }}>
            Join Picsart Champion to get paid for your content. Create AI-powered
            visuals, post them on social media, and earn rewards based on your views
            and performance.
          </p>
          <div className="land-earnings land-anim" style={{ animationDelay: '0.5s' }}>
            <span className="land-earnings-label">Total earnings by all creators</span>
            <span className="land-earnings-value">$2,147,893</span>
          </div>
          <button
            className="land-cta land-anim"
            style={{ animationDelay: '0.65s' }}
            onClick={onGetStarted}
          >
            Start Earning <span className="land-cta-sparkle">&#10022;</span>
          </button>
        </div>

        <div className="land-hero-img land-anim" style={{ animationDelay: '0.4s' }}>
          <img src="https://picsum.photos/seed/picsart-hero/600/720" alt="" />
        </div>
        </div>
      </section>

      {/* ── AI Tools Banner ── */}
      <section className="land-banner land-anim" style={{ animationDelay: '0.8s' }}>
        <div className="land-banner-coins">
          <span className="land-coin land-coin--1">&#9679;</span>
          <span className="land-coin land-coin--2">$</span>
          <span className="land-coin land-coin--3">&#9679;</span>
        </div>
        <div className="land-banner-text">
          <strong>CREATE WITH PICSART AI TOOLS</strong>
          <span>Turn your creativity into income with our industry-leading AI suite</span>
        </div>
        <button className="land-banner-btn" onClick={onGetStarted}>
          Submit &amp; Earn
        </button>
      </section>

      {/* ── 3 Steps ── */}
      <section className="land-steps">
        <h2 className="land-section-title">3 SIMPLE STEPS TO MAKE MONEY</h2>
        <div className="land-steps-grid">
          {STEPS.map((step) => (
            <div className="land-step-card" key={step.id}>
              <div className={`land-step-visual land-step-visual--${step.id}`}>
                {step.id === 'signup' && (
                  <div className="land-visual-signup">
                    <div className="land-check-circle">&#10003;</div>
                    <div className="land-check-particles">
                      <span />
                      <span />
                      <span />
                      <span />
                      <span />
                      <span />
                    </div>
                    <span className="land-visual-label">Verified successfully</span>
                  </div>
                )}
                {step.id === 'create' && (
                  <div className="land-visual-create">
                    <img className="land-create-preview" src="https://picsum.photos/seed/picsart-create/200/248" alt="" />
                    <div className="land-create-actions">
                      <span className="land-create-action">&#9998;</span>
                      <span className="land-create-action">&#128279;</span>
                      <span className="land-create-action">&#128465;</span>
                    </div>
                    <span className="land-create-cursor">&#9756;</span>
                  </div>
                )}
                {step.id === 'earn' && (
                  <div className="land-visual-earn">
                    <span className="land-earn-label">Balance</span>
                    <span className="land-earn-amount">$2,500</span>
                    <button className="land-earn-claim">
                      &#9432; Claim your money
                    </button>
                  </div>
                )}
              </div>
              <span className="land-step-num">STEP {step.num}</span>
              <h3 className="land-step-title">{step.title}</h3>
              <p className="land-step-desc">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Growth Income ── */}
      <section className="land-growth">
        <div className="land-growth-text">
          <span className="land-growth-badge">GROWTH INCOME</span>
          <h2 className="land-growth-title">
            BOOST YOUR EARNINGS BY 150% WITH PICSART CHAMPION
          </h2>
          <p className="land-growth-desc">
            The longer your content stays relevant, the more you earn. Our smart
            tracking system monitors your content 24/7, automatically adding
            earnings to your balance as you hit new view milestones.
          </p>
          <button className="land-growth-btn" onClick={onGetStarted}>
            <span className="land-cta-sparkle">&#10022;</span> Start Now!
          </button>
        </div>
        <div className="land-growth-chart">
          <svg viewBox="0 0 300 200" className="land-chart-svg">
            <defs>
              <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#C12CD1" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#C12CD1" stopOpacity="0" />
              </linearGradient>
              <filter id="chartGlow">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* grid */}
            <line x1="40" y1="20" x2="40" y2="180" stroke="rgba(255,255,255,0.06)" />
            <line x1="40" y1="180" x2="280" y2="180" stroke="rgba(255,255,255,0.06)" />
            {[140, 100, 60].map((y) => (
              <line
                key={y}
                x1="40"
                y1={y}
                x2="280"
                y2={y}
                stroke="rgba(255,255,255,0.04)"
                strokeDasharray="4"
              />
            ))}

            {/* Y labels */}
            <text x="35" y="183" fill="rgba(255,255,255,0.35)" fontSize="8" textAnchor="end">$100</text>
            <text x="35" y="143" fill="rgba(255,255,255,0.35)" fontSize="8" textAnchor="end">$500</text>
            <text x="35" y="103" fill="rgba(255,255,255,0.35)" fontSize="8" textAnchor="end">$800</text>
            <text x="35" y="63" fill="rgba(255,255,255,0.35)" fontSize="8" textAnchor="end">$1,300</text>

            {/* X labels */}
            <text x="70" y="195" fill="rgba(255,255,255,0.3)" fontSize="8" textAnchor="middle">Day 1</text>
            <text x="160" y="195" fill="rgba(255,255,255,0.3)" fontSize="8" textAnchor="middle">Day 3</text>
            <text x="260" y="195" fill="#C12CD1" fontSize="9" fontWeight="bold" textAnchor="middle">Day 7</text>

            {/* area */}
            <path
              d="M70,172 C100,168 130,158 160,138 C190,118 230,70 260,38 L260,180 L70,180 Z"
              fill="url(#chartFill)"
            />

            {/* line */}
            <path
              d="M70,172 C100,168 130,158 160,138 C190,118 230,70 260,38"
              fill="none"
              stroke="#C12CD1"
              strokeWidth="2.5"
              strokeLinecap="round"
              filter="url(#chartGlow)"
              className="land-chart-line"
            />

            {/* endpoint */}
            <circle cx="260" cy="38" r="6" fill="#C12CD1" filter="url(#chartGlow)" />
            <circle cx="260" cy="38" r="3.5" fill="#0a0a0a" />
            <circle cx="260" cy="38" r="2" fill="#C12CD1" />
          </svg>

          <div className="land-chart-tooltip">
            <span className="land-chart-tooltip-val">+$1,300</span>
            <span className="land-chart-tooltip-sub">Weekly earnings</span>
          </div>
        </div>
      </section>

      {/* ── Campaigns ── */}
      <section className="land-campaigns">
        <div className="land-campaigns-header">
          <span className="land-campaigns-tag">TRENDING NOW</span>
          <h2 className="land-campaigns-title">
            JOIN THE HIGHEST PAYING CAMPAIGNS{' '}
            <span className="land-pink">RIGHT NOW</span>
          </h2>
          <p className="land-campaigns-desc">
            It&rsquo;s simple: Choose a campaign, create content with Picsart AI tools,
            and upload your video. Each campaign has clear guidelines and transparent
            payout caps.
          </p>
          <button className="land-campaigns-btn" onClick={onGetStarted}>
            Join the Hype
          </button>
        </div>

        <div className="land-campaigns-scroll">
          {CAMPAIGNS.map((c) => (
            <div className="land-campaign-card" key={c.title}>
              <img className="land-campaign-img" src={c.img} alt={c.title} />
              <div className="land-campaign-body">
                <span className="land-campaign-platform">{c.platform}</span>
                <h3 className="land-campaign-name">{c.title}</h3>
                <p className="land-campaign-desc">{c.desc}</p>
                <div className="land-campaign-meta">
                  <div>
                    <span className="land-campaign-meta-label">Payout</span>
                    <span className="land-campaign-meta-val">{c.payout}</span>
                  </div>
                  <div>
                    <span className="land-campaign-meta-label">End Date</span>
                    <span className="land-campaign-meta-val">{c.endDate}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section className="land-final">
        <div className="land-final-orb" />
        <h2 className="land-final-title">READY TO START EARNING?</h2>
        <p className="land-final-desc">
          Join 10,000+ creators already earning with Picsart Champion.
          No follower minimum required.
        </p>
        <button className="land-cta" onClick={onGetStarted}>
          Start Earning <span className="land-cta-sparkle">&#10022;</span>
        </button>
      </section>
    </div>
  );
}
