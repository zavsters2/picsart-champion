import { Avatar } from '@picsart/design-system/components/Avatar';
import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { Chip, ChipSkins } from '@picsart/design-system/components/Chip';
import { MOCK_LEADERBOARD } from '../data/mock';
import './Leaderboard.css';

function formatNumber(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

export default function Leaderboard() {
  return (
    <div className="leaderboard-page">
      <Text elementType={TextElementTypes.H1} className="lb-title">Leaderboard</Text>
      <Text elementType={TextElementTypes.P} className="lb-subtitle">Top champions this month</Text>

      <div className="lb-podium">
        {MOCK_LEADERBOARD.slice(0, 3).map((user, i) => (
          <div className={`podium-item podium-${i + 1}`} key={user.rank}>
            <Text elementType={TextElementTypes.Span} className="podium-rank">#{user.rank}</Text>
            <Avatar
              size={i === 0 ? 60 : 48}
              initials={user.name.charAt(0)}
              imageAlt={user.name}
            />
            <Text elementType={TextElementTypes.Span} className="podium-name">{user.name.split(' ')[0]}</Text>
            <Text elementType={TextElementTypes.Span} className="podium-views">{formatNumber(user.views)}</Text>
          </div>
        ))}
      </div>

      <div className="lb-list">
        {MOCK_LEADERBOARD.map((user) => (
          <div
            className={`lb-row ${user.isCurrentUser ? 'lb-row--current' : ''}`}
            key={user.rank}
          >
            <Text elementType={TextElementTypes.Span} className="lb-rank">#{user.rank}</Text>
            <div className="lb-user">
              <Avatar
                size={36}
                initials={user.name.charAt(0)}
                imageAlt={user.name}
              />
              <div className="lb-user-info">
                <div className="lb-user-name-row">
                  <Text elementType={TextElementTypes.Span} className="lb-user-name">{user.name}</Text>
                  {user.isCurrentUser && (
                    <Chip text="YOU" skin={ChipSkins.Primary} isActive />
                  )}
                </div>
                <Text elementType={TextElementTypes.Span} className="lb-user-handle">{user.handle}</Text>
              </div>
            </div>
            <div className="lb-stats">
              <Text elementType={TextElementTypes.Span} className="lb-stat-views">{formatNumber(user.views)}</Text>
              <Text elementType={TextElementTypes.Span} className="lb-stat-earnings">${formatNumber(user.earnings)}</Text>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
