import Header from '../components/Header';
import './Login.css';

export default function Login({ onLogin }) {
  return (
    <div className="login-page">
      <Header onLogin={onLogin} minimal />
      {/* Left: decorative creative collage */}
      <div className="login-left">
        <img
          src="https://picsum.photos/seed/picsart-login/900/1200"
          alt=""
          className="login-left-img"
        />
        <div className="login-left-overlay" />
        <div className="login-left-ui">
          <div className="login-ui-toolbar">
            <span className="login-ui-dot" />
            <span className="login-ui-dot" />
            <span className="login-ui-dot" />
            <div className="login-ui-tabs">
              <span className="login-ui-tab login-ui-tab--active">Edit</span>
              <span className="login-ui-tab">Adjust</span>
              <span className="login-ui-tab">Effects</span>
              <span className="login-ui-tab">RemoveBG</span>
            </div>
          </div>
          <div className="login-ui-sliders">
            <div className="login-ui-slider">
              <span>Saturation</span>
              <div className="login-ui-track"><div className="login-ui-fill" style={{ width: '65%' }} /></div>
            </div>
            <div className="login-ui-slider">
              <span>Brightness</span>
              <div className="login-ui-track"><div className="login-ui-fill" style={{ width: '50%' }} /></div>
            </div>
            <div className="login-ui-slider">
              <span>Contrast</span>
              <div className="login-ui-track"><div className="login-ui-fill" style={{ width: '40%' }} /></div>
            </div>
          </div>
        </div>
      </div>

      {/* Right: login card */}
      <div className="login-right">
        <div className="login-card">
          <h1 className="login-heading">Jump back in</h1>

          <div className="login-accounts">
            <button className="login-account" onClick={onLogin}>
              <span className="login-account-icon">
                <svg width="20" height="16" viewBox="0 0 20 16" fill="none">
                  <rect x="1" y="1" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M1 3l9 5 9-5" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                </svg>
              </span>
              <span className="login-account-label">Continue with sarah@email.com</span>
            </button>

            <button className="login-account" onClick={onLogin}>
              <span className="login-account-icon">
                <svg width="20" height="16" viewBox="0 0 20 16" fill="none">
                  <rect x="1" y="1" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M1 3l9 5 9-5" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                </svg>
              </span>
              <span className="login-account-label">Continue with alex.creator</span>
            </button>

            <button className="login-account login-account--alt" onClick={onLogin}>
              <span className="login-account-label">Continue with another account</span>
            </button>
          </div>

          <p className="login-terms">
            By continuing, you agree to our{' '}
            <a href="#terms" onClick={(e) => e.preventDefault()}>Terms of Use</a>{' '}
            and{' '}
            <a href="#privacy" onClick={(e) => e.preventDefault()}>Privacy Policy</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
