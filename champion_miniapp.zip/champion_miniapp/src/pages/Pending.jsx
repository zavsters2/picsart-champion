import { Button, ButtonVariants, ButtonSizeLG } from '@picsart/design-system/components/Button';
import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { Progress, ProgressVariants } from '@picsart/design-system/components/Progress';
import './Pending.css';

export default function Pending({ onApprove }) {
  return (
    <div className="pending-page">
      <div className="pending-icon">&#x23F3;</div>
      <Text elementType={TextElementTypes.H1} className="pending-title">
        Application Submitted!
      </Text>
      <Text elementType={TextElementTypes.P} className="pending-text">
        We're reviewing your profile. You'll hear back within 24-48 hours.
        We check for content quality, authenticity, and basic activity — no follower
        minimums.
      </Text>

      <div className="pending-checklist">
        <div className="check-item check-done">Profile reviewed</div>
        <div className="check-item check-active">Content quality check</div>
        <div className="check-item">Approval decision</div>
      </div>

      <Progress variant={ProgressVariants.Linear} percent={55} isFullWidth />

      <Button
        variant={ButtonVariants.Outline}
        size={ButtonSizeLG}
        onClick={onApprove}
      >
        Skip to dashboard (demo)
      </Button>
    </div>
  );
}
