import { useState } from 'react';
import { MOCK_POSTS, VIEW_MILESTONES } from '../data/mock';
import './Posts.css';

function formatNumber(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

function getNextMilestone(views) {
  return VIEW_MILESTONES.find((m) => views < m.views);
}

const PLATFORM_ICONS = {
  TikTok: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M10 2v7a3 3 0 11-2.5-2.96" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
      <path d="M10 4.5c1 .8 2.2 1 3 1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
    </svg>
  ),
  Instagram: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="1" width="14" height="14" rx="4" stroke="currentColor" strokeWidth="1.3"/>
      <circle cx="8" cy="8" r="3.2" stroke="currentColor" strokeWidth="1.3"/>
      <circle cx="12" cy="4" r="1" fill="currentColor"/>
    </svg>
  ),
  'YouTube Shorts': (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="10" rx="3" stroke="currentColor" strokeWidth="1.3"/>
      <path d="M6.5 6v4l3.5-2-3.5-2z" fill="currentColor"/>
    </svg>
  ),
};

const FILTERS = ['All', 'Approved', 'Pending'];

export default function Posts() {
  const [filter, setFilter] = useState('All');

  const filtered = filter === 'All'
    ? MOCK_POSTS
    : MOCK_POSTS.filter((p) => p.status === filter.toLowerCase());

  const approvedCount = MOCK_POSTS.filter((p) => p.status === 'approved').length;

  return (
    <div className="posts-page">
      {/* Header */}
      <div className="posts-header">
        <div>
          <h1 className="posts-title">Submitted Posts</h1>
          <p className="posts-subtitle">
            {MOCK_POSTS.length} posts — {approvedCount} approved
          </p>
        </div>
        <div className="posts-filters">
          {FILTERS.map((f) => (
            <button
              key={f}
              className={`posts-filter ${filter === f ? 'posts-filter--active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Posts table (desktop) */}
      <div className="posts-table">
        <div className="posts-table-head">
          <span className="pt-col pt-col--post">Post</span>
          <span className="pt-col pt-col--status">Status</span>
          <span className="pt-col pt-col--views">Views</span>
          <span className="pt-col pt-col--likes">Likes</span>
          <span className="pt-col pt-col--installs">Installs</span>
          <span className="pt-col pt-col--earned">Earned</span>
          <span className="pt-col pt-col--milestone">Next Milestone</span>
        </div>

        {filtered.map((post) => {
          const next = getNextMilestone(post.views);
          const nextPct = next ? Math.min((post.views / next.views) * 100, 100) : 100;
          return (
            <div className="posts-table-row" key={post.id}>
              <div className="pt-col pt-col--post">
                <img src={post.thumbnail} alt="" className="pt-thumb" />
                <div className="pt-post-info">
                  <span className="pt-platform">
                    {PLATFORM_ICONS[post.platform]}
                    {post.platform}
                  </span>
                  <span className="pt-caption">{post.caption}</span>
                  <span className="pt-date">{post.postedAt}</span>
                </div>
              </div>

              <div className="pt-col pt-col--status">
                <span className={`pt-status pt-status--${post.status}`}>
                  {post.status}
                </span>
              </div>

              <div className="pt-col pt-col--views">
                <span className="pt-stat-value">{formatNumber(post.views)}</span>
              </div>
              <div className="pt-col pt-col--likes">
                <span className="pt-stat-value">{formatNumber(post.likes)}</span>
              </div>
              <div className="pt-col pt-col--installs">
                <span className="pt-stat-value">{post.installs}</span>
              </div>
              <div className="pt-col pt-col--earned">
                <span className="pt-stat-value pt-stat-value--earned">${post.earnings}</span>
              </div>

              <div className="pt-col pt-col--milestone">
                {next ? (
                  <div className="pt-milestone">
                    <div className="pt-milestone-bar">
                      <div className="pt-milestone-fill" style={{ width: `${nextPct}%` }} />
                    </div>
                    <span className="pt-milestone-text">
                      {formatNumber(next.views - post.views)} to +${next.bonus}
                    </span>
                  </div>
                ) : (
                  <span className="pt-milestone-done">All reached</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile card layout */}
      <div className="posts-cards">
        {filtered.map((post) => {
          const next = getNextMilestone(post.views);
          const nextPct = next ? Math.min((post.views / next.views) * 100, 100) : 100;
          return (
            <div className="post-card" key={post.id}>
              <div className="post-card-top">
                <img src={post.thumbnail} alt="" className="post-card-thumb" />
                <div className="post-card-info">
                  <div className="post-card-row">
                    <span className="post-card-platform">
                      {PLATFORM_ICONS[post.platform]}
                      {post.platform}
                    </span>
                    <span className={`pt-status pt-status--${post.status}`}>
                      {post.status}
                    </span>
                  </div>
                  <span className="post-card-caption">{post.caption}</span>
                  <span className="post-card-date">{post.postedAt}</span>
                </div>
              </div>

              <div className="post-card-stats">
                <div className="post-card-stat">
                  <span className="post-card-stat-val">{formatNumber(post.views)}</span>
                  <span className="post-card-stat-lbl">Views</span>
                </div>
                <div className="post-card-stat">
                  <span className="post-card-stat-val">{formatNumber(post.likes)}</span>
                  <span className="post-card-stat-lbl">Likes</span>
                </div>
                <div className="post-card-stat">
                  <span className="post-card-stat-val">{post.installs}</span>
                  <span className="post-card-stat-lbl">Installs</span>
                </div>
                <div className="post-card-stat">
                  <span className="post-card-stat-val post-card-stat-val--earned">${post.earnings}</span>
                  <span className="post-card-stat-lbl">Earned</span>
                </div>
              </div>

              {next && (
                <div className="post-card-milestone">
                  <div className="pt-milestone-bar">
                    <div className="pt-milestone-fill" style={{ width: `${nextPct}%` }} />
                  </div>
                  <span className="pt-milestone-text">
                    {formatNumber(next.views - post.views)} views to +${next.bonus} bonus
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
