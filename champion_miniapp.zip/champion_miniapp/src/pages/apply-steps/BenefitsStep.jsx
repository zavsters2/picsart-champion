import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { Divider } from '@picsart/design-system/components/Divider';
import { LEVELS } from '../../data/mock';

const PERKS = [
  { icon: '$', title: '$5–15 per post', desc: 'Base pay for every qualifying post' },
  { icon: '\u2191', title: 'View bonuses', desc: 'Up to $500 for viral content' },
  { icon: '\u2605', title: 'Early access', desc: 'Try new AI features 48–72h early' },
];

export default function BenefitsStep() {
  return (
    <div className="benefits-step">
      <Text elementType={TextElementTypes.H2} className="step-title">What You'll Earn</Text>

      <div className="benefits-perks">
        {PERKS.map((p) => (
          <div className="perk" key={p.title}>
            <div className="perk-icon">{p.icon}</div>
            <div>
              <Text elementType={TextElementTypes.Strong}>{p.title}</Text>
              <Text elementType={TextElementTypes.Span} className="perk-desc">{p.desc}</Text>
            </div>
          </div>
        ))}
      </div>

      <Divider />

      <Text elementType={TextElementTypes.H3} className="step-title">Level Up As You Grow</Text>
      <div className="tier-track">
        {LEVELS.map((lvl, i) => (
          <div className="tier-item" key={lvl.name}>
            <div className="tier-dot" style={{ background: lvl.color }} />
            {i < LEVELS.length - 1 && <div className="tier-line" />}
            <Text elementType={TextElementTypes.Strong} className="tier-name">{lvl.name}</Text>
            <Text elementType={TextElementTypes.Span} className="tier-rate">${lvl.baseRate}/post</Text>
          </div>
        ))}
      </div>
    </div>
  );
}
