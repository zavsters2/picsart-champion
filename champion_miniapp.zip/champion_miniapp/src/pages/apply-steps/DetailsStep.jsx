import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { TextField, ControlSizesLG } from '@picsart/design-system/components/TextField';
import { TextArea } from '@picsart/design-system/components/TextArea';

export default function DetailsStep({ formData, setFormData }) {
  const update = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="details-step">
      <Text elementType={TextElementTypes.H2} className="step-title">About You</Text>
      <Text elementType={TextElementTypes.P} className="step-subtitle">
        We'll use this to set up your Champion account
      </Text>

      <div className="field">
        <Text elementType={TextElementTypes.Label} className="field-label">
          Full Name <span className="field-required">*</span>
        </Text>
        <TextField
          size={ControlSizesLG}
          placeholder="Your name"
          value={formData.name}
          onChange={(e) => update('name', e.target.value)}
        />
      </div>

      <div className="field">
        <Text elementType={TextElementTypes.Label} className="field-label">
          Email <span className="field-required">*</span>
        </Text>
        <TextField
          size={ControlSizesLG}
          type="email"
          placeholder="you@example.com"
          value={formData.email}
          onChange={(e) => update('email', e.target.value)}
        />
      </div>

      <div className="field">
        <Text elementType={TextElementTypes.Label} className="field-label">
          Why do you want to join? (optional)
        </Text>
        <TextArea
          size={ControlSizesLG}
          placeholder="Tell us a bit about yourself and what you create..."
          value={formData.whyJoin}
          onChange={(e) => update('whyJoin', e.target.value)}
        />
      </div>
    </div>
  );
}
