import { Text, TextElementTypes } from '@picsart/design-system/components/Text';

const STEPS = [
  {
    num: '1',
    title: 'Create with AI Tools',
    desc: 'Use Picsart\'s AI features to create stunning photos, videos, and edits',
  },
  {
    num: '2',
    title: 'Share on Social',
    desc: 'Post to your favorite platforms and tag #picsart or mention @picsart',
  },
  {
    num: '3',
    title: 'Earn Money',
    desc: 'Get $5–15 per post plus bonuses based on views — up to $500',
  },
];

export default function HowItWorksStep() {
  return (
    <div className="hiw-step">
      <Text elementType={TextElementTypes.H2} className="step-title">How It Works</Text>
      <Text elementType={TextElementTypes.P} className="step-subtitle">Three simple steps to start earning</Text>
      <div className="hiw-cards">
        {STEPS.map((s) => (
          <div className="hiw-card" key={s.num}>
            <div className="hiw-num">{s.num}</div>
            <div className="hiw-card-text">
              <Text elementType={TextElementTypes.Strong}>{s.title}</Text>
              <Text elementType={TextElementTypes.Span} className="hiw-card-desc">{s.desc}</Text>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
