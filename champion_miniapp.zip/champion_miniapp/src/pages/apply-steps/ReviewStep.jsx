import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { Chip, ChipSkins } from '@picsart/design-system/components/Chip';
import { Divider } from '@picsart/design-system/components/Divider';

export default function ReviewStep({ formData, goToStep }) {
  return (
    <div className="review-step">
      <Text elementType={TextElementTypes.H2} className="step-title">Review Your Application</Text>

      <div className="review-section">
        <div className="review-section-header">
          <Text elementType={TextElementTypes.Label} className="review-label">Contact Info</Text>
          <button className="review-edit" onClick={() => goToStep(3)}>Edit</button>
        </div>
        <div className="review-detail">
          <Text elementType={TextElementTypes.Strong}>{formData.name}</Text>
          <Text elementType={TextElementTypes.Span} className="review-detail-sub">{formData.email}</Text>
        </div>
      </div>

      <Divider />

      <div className="review-section">
        <div className="review-section-header">
          <Text elementType={TextElementTypes.Label} className="review-label">Social Accounts</Text>
          <button className="review-edit" onClick={() => goToStep(4)}>Edit</button>
        </div>
        <div className="platform-chips">
          {formData.platforms.map((p) => (
            <Chip key={p} text={p} skin={ChipSkins.Primary} isActive />
          ))}
        </div>
        <div className="review-handles">
          {formData.platforms.map((p) => (
            <div className="review-handle-row" key={p}>
              <Text elementType={TextElementTypes.Span} className="review-handle-platform">{p}</Text>
              <Text elementType={TextElementTypes.Span} className="review-handle-value">
                {formData.handles[p] || '—'}
              </Text>
            </div>
          ))}
        </div>
      </div>

      {formData.whyJoin && (
        <>
          <Divider />
          <div className="review-section">
            <div className="review-section-header">
              <Text elementType={TextElementTypes.Label} className="review-label">Why Join</Text>
              <button className="review-edit" onClick={() => goToStep(3)}>Edit</button>
            </div>
            <Text elementType={TextElementTypes.P} className="review-why">{formData.whyJoin}</Text>
          </div>
        </>
      )}

      <Divider />

      <Text elementType={TextElementTypes.P} className="review-note">
        We review applications within 24–48 hours. No minimum follower count required.
      </Text>
    </div>
  );
}
