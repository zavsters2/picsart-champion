import { Text, TextElementTypes } from '@picsart/design-system/components/Text';
import { TextField, ControlSizesLG } from '@picsart/design-system/components/TextField';

const PLATFORMS = [
  { id: 'TikTok', placeholder: '@username' },
  { id: 'Instagram', placeholder: '@username' },
  { id: 'YouTube', placeholder: '@channel or URL' },
  { id: 'Pinterest', placeholder: '@username' },
  { id: 'Twitter/X', placeholder: '@handle' },
];

export default function SocialsStep({ formData, setFormData }) {
  const setHandle = (id, value) => {
    setFormData((prev) => {
      const handles = { ...prev.handles, [id]: value };
      const platforms = PLATFORMS.map((p) => p.id).filter(
        (pid) => (handles[pid] || '').trim() !== '',
      );
      return { ...prev, handles, platforms };
    });
  };

  const filled = formData.platforms.length;

  return (
    <div className="socials-step">
      <Text elementType={TextElementTypes.H2} className="step-title">
        Your Social Accounts
      </Text>
      <Text elementType={TextElementTypes.P} className="step-subtitle">
        Enter at least one handle so we know where to find you.
      </Text>

      <div className="socials-fields">
        {PLATFORMS.map((p) => (
          <div className="field" key={p.id}>
            <Text elementType={TextElementTypes.Label} className="field-label">
              {p.id}
            </Text>
            <TextField
              size={ControlSizesLG}
              placeholder={p.placeholder}
              value={formData.handles[p.id] || ''}
              onChange={(e) => setHandle(p.id, e.target.value)}
            />
          </div>
        ))}
      </div>

      <Text
        elementType={TextElementTypes.Span}
        className={`platforms-hint ${filled > 0 ? 'platforms-hint--valid' : ''}`}
      >
        {filled > 0
          ? `${filled} platform${filled > 1 ? 's' : ''} added`
          : 'Fill in at least one'}
      </Text>
    </div>
  );
}
