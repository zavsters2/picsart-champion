import { Text, TextElementTypes } from '@picsart/design-system/components/Text';

const HIGHLIGHTS = [
  { icon: '$', text: '$5–15 per post' },
  { icon: '\u2191', text: 'Up to $500 bonuses' },
  { icon: '\u2605', text: 'Early AI access' },
];

export default function WelcomeStep() {
  return (
    <div className="welcome-step">
      <div className="welcome-orb" />
      <div className="welcome-orb welcome-orb--2" />

      <div className="welcome-badge anim-fade" style={{ animationDelay: '0.1s' }}>
        CHAMPION PROGRAM
      </div>

      <Text
        elementType={TextElementTypes.H1}
        className="welcome-title anim-fade"
        style={{ animationDelay: '0.25s' }}
      >
        Become a Picsart Champion
      </Text>

      <Text
        elementType={TextElementTypes.P}
        className="welcome-subtitle anim-fade"
        style={{ animationDelay: '0.4s' }}
      >
        Earn $50–500+/month sharing what you create with Picsart AI tools.
        No follower minimum.
      </Text>

      <div className="welcome-stats anim-fade" style={{ animationDelay: '0.55s' }}>
        <div className="welcome-stat">
          <span className="welcome-stat-num">10K+</span>
          <span className="welcome-stat-label">Creators</span>
        </div>
        <div className="welcome-stat-divider" />
        <div className="welcome-stat">
          <span className="welcome-stat-num">$2M+</span>
          <span className="welcome-stat-label">Paid out</span>
        </div>
        <div className="welcome-stat-divider" />
        <div className="welcome-stat">
          <span className="welcome-stat-num">48h</span>
          <span className="welcome-stat-label">Approval</span>
        </div>
      </div>

      <div className="welcome-highlights">
        {HIGHLIGHTS.map((h, i) => (
          <div
            className="welcome-highlight anim-fade"
            key={h.text}
            style={{ animationDelay: `${0.65 + i * 0.1}s` }}
          >
            <span className="welcome-highlight-icon">{h.icon}</span>
            <span>{h.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
