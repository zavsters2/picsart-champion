import { createContext } from '@picsart/miniapps-sdk';

let picsartContext = null;

export function initPicsart() {
  if (picsartContext) return picsartContext;
  try {
    const { getContext } = createContext();
    picsartContext = getContext();
  } catch (e) {
    // Running outside Picsart (local dev) — use stub
    console.info('[Champion] Running outside Picsart editor, using defaults.', e?.message || '');
    picsartContext = null;
  }
  return picsartContext;
}

export function getPicsartContext() {
  return picsartContext;
}

export function isInsidePicsart() {
  return picsartContext !== null;
}
