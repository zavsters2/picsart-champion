import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'
import { copyFileSync } from 'fs'

// Copy extension-manifest.json to public/ so it's served at root
function copyManifestPlugin() {
  return {
    name: 'copy-manifest-plugin',
    buildStart() {
      const src = resolve(import.meta.dirname, 'extension-manifest.json');
      const dest = resolve(import.meta.dirname, 'public', 'extension-manifest.json');
      copyFileSync(src, dest);
    },
  };
}

const PICSART_HOST_URL = 'https://picsart.com/create/editor';

export default defineConfig({
  plugins: [
    react(),
    // Auto-open in Picsart editor disabled for standalone prototyping
    // To re-enable: import open from 'open' and uncomment below
    // {
    //   name: 'open-picsart-editor',
    //   configureServer(server) {
    //     server.httpServer?.once('listening', () => {
    //       const port = server.config.server.port;
    //       const url = `http://localhost:${port}`;
    //       const encoded = encodeURIComponent(url);
    //       const editorUrl = `${PICSART_HOST_URL}?miniapp_server=${encoded}&category=miniapps&app=com.picsart.edit.champion-program`;
    //       console.log(`\n  Open in Picsart Editor: ${editorUrl}\n`);
    //       open(editorUrl);
    //     });
    //   },
    // },
    copyManifestPlugin(),
  ],
  server: {
    port: 5180,
    cors: true,
  },
})
